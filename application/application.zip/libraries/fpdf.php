<?php
class fpdf {
 
    function __construct() {
        include_once APPPATH . '/third_party/fpdf/fpdf.php';
    }
}
?>